import React, {useState, useContext} from "react"; 
import detailsContext from "../contexts/context"
import NavBar from '../contexts/Navbar';

const Profile = () => { 
    const {val} = useContext(detailsContext); 
    return ( 
        <div> 
            <NavBar/>
            {console.log(val)}
            <p>{val.name}</p>
            <p>{val.email}</p>
            <p>{val.college}</p>
             {val.role === 0?<p>Student</p>:(val.role === 1)?<p>Faculty</p>:""}
        </div> 
    ) 
} 
export default Profile;