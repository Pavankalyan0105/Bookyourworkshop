import React, {useEffect , useState} from "react"; 
import axios from "axios"; 
import Razorpay from 'razorpay';
import {Navigate} from "react-router-dom";
import Myworkshops from "./Myworkshops"
import "./css/Card.css";
const Card = ({workshop}) =>{ 
    const [ token , setToken ] = useState("")
    const [ userId , setUserId ] = useState("")
    const [ booked , setBooked] = useState(false)

    const bookMyWorkshop =  async () => {
        console.log("Booking...")

        await axios.post(
            `http://localhost:8000/api/workshop/book/${localStorage.getItem("id")}/${workshop._id}`,
            { headers: {"Authorization" : `Bearer ${ localStorage.getItem("token")}`} }
          ).
          then(
              (res) => {
                console.log(res.data)
              }
          ).catch(
              err => console.log(err)
          )
    }

    const initPayment = (data) => {
		const options = {
			key: "rzp_test_75sXdBCKAt28Vo",
			amount: data.amount,
			currency: data.currency,
			name: workshop.name,
			description: "Test Transaction",
			image: "../../public/logo192.png",
			order_id: data.id,
			handler: async (response) => {
				try {
					const verifyUrl = "http://localhost:8000/api/payment/verify";
					const { data } = await axios.post(verifyUrl, response);
					console.log(data.message === "Payment verified successfully");
                    if(data && data.message === "Payment verified successfully"){
                            bookMyWorkshop()
                    }

				} catch (error) {
					console.log(error);
				}
			},
			theme: {
				color: "#3399cc",
			},
		};
		const rzp1 = new window.Razorpay(options);
        rzp1.open();
        
	};

	const handlePayment = async () => {
		try {
			const orderUrl = "http://localhost:8000/api/payment/orders";
			const { data } = await axios.post(orderUrl, { amount: workshop.amount });
			console.log(data);
			initPayment(data.data);
		} catch (error) {
			console.log(error);
		}


	};

    

    useEffect( () => {
        setToken(localStorage.getItem("token"))
        setUserId(localStorage.getItem("id"))
    } , [])


    if(booked)
        return <Navigate to="/"/>

    return( 
        // <div className="card" style={{width: "18rem"}}> 
        //     <img 
        //         src="https://images.pexels.com/photos/3532557/pexels-photo-3532557.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" 
        //         className="card-img-top" 
        //         alt="..." 
        //     /> 
        //     <div className="card-body"> 
        //         {console.log(workshop)}
        //         <h5 className="card-title">{workshop.name}</h5> 
        //         <p className="card-text"> 
        //         {workshop._id} 
        //         </p> 
        //         {/* <button onClick = {() => bookMyWorkshop(workshop._id) }>Book</button> */}
        //         <button onClick = {handlePayment}>Book</button>
        //     </div> 

            <div className="card-container"> 
                <div className="image-container"> 
                    <img 
                        src="https://images.pexels.com/photos/3532557/pexels-photo-3532557.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" 
                        alt="..." 
                    /> 
                </div> 
                <div className="card-content"> 
                    <div className="card-title"> 
                        <h3>{workshop.name}</h3> 
                    </div> 
                    <div className="card-body"> 
                       <p> id={workshop._id}</p> 
                       <p>kran</p> 
                       <p>kran</p> 
                       <p>kran</p> 
                       <p>kran</p> 
 
                    </div> 
                </div> 
                 
                <div className="btn" > 
                    <button  onClick={handlePayment}>book</button> 
                </div> 
                
            </div> 


            
        // </div> 
    ) 
} 
 
export default Card;