import React from "react";
import { Link, Outlet } from "react-router-dom";

const Select = () => (
    <div className="Select">
        <Link to="/components/Select/StudentRegister">
        <button 
        type="submit"
        id = "student"
        >Student </button>
        </Link>
        <Link to = "/components/Select/FacultyRegistration">
        <button
        type="submit"
        id = "faculty"
        >Faculty</button>
        </Link>
        <Outlet />
    </div>
)
export default Select;