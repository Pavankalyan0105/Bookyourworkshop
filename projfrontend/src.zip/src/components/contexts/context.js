import React from "react";

const detailsContext = React.createContext();

export default detailsContext;