import React,{useState , useEffect} from "react"; 
import axios from 'axios'; 
import { Navigate } from "react-router-dom";
import NavBar from './contexts/Navbar.js'

const Create = () => { 

    const [role , setRole ] = useState(0)

    const [details, setDetails] = useState({ 
        name: "", 
        info: "", 
        amount : 0, 
        seats: 0, 
        accno: "", 
        IFSC : "", 
        date:"", 
        fromTime:"", 
        toTime:"", 
        instructor:""
    }) 

    


    const handleSubmit = async (e) => {
        e.preventDefault();

        const {name, info, amount , seats ,accno , date ,IFSC, fromTime , toTime , instructor} = details;

        const token = {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
        };
        
        const body = {
            name: name,
            info: info,
            amount: amount,
            seats: seats,
            accno: accno,
            IFSC: IFSC,
            date: date,
            fromTime: fromTime,
            toTime: toTime,
            instructor: instructor
        };

        axios.post(
            `http://localhost:8000/api/workshop/create/${localStorage.getItem("id")}`,
            { 
                body , token
            }
          ).then(
              res => console.log(res.data)
          )

    }

    useEffect( () => {
        setRole(localStorage.getItem("role"))
    } , [])

    if(role === "0") {
        console.log("Redirecting ....");

        return <Navigate to="/"/>
    }


    return ( 
        <form onSubmit={handleSubmit}> 
            <NavBar/>
            <br /> 
            <h1>Create New workshop</h1> 
            Enter Your name:  
            <input  
            type="text"  
            name="firstname"  
            id = "firstname"  
            placeholder="Enter First Name" 
            onChange={e => setDetails({...details, name:e.target.value})} 
            value={details.name} 
            /><br /> 
            Enter info: 
            <input  
            type="text" 
            name="info" 
            id="info"  
            placeholder="Enter info related to workshop" 
            onChange={e => setDetails({...details,info:e.target.value})} 
            value={details.info} 
            /><br /> 
 
            amount 
            <input  
            type="number" 
            name="amount" 
            id="amount"  
            placeholder="Enter amout" 
            onChange={e => setDetails({...details,amount:e.target.value})} 
            value={details.amount} 
            /><br /> 
 
            seats 
            <input  
                type="number" 
                name="seats" 
                id="seats"  
                placeholder="Enter seats" 
                onChange={e => setDetails({...details,seats:e.target.value})} 
                value={details.seats} 
            /><br /> 
 
            accno 
            <input  
                type="number" 
                name="accno" 
                id="accno"  
                placeholder="Enter accno" 
                onChange={e => setDetails({...details,accno:e.target.value})} 
                value={details.accno} 
            /><br /> 
 
            IFSC 
            <input  
                type="text" 
                name="IFSC" 
                id="IFSC"  
                placeholder="Enter IFSC code" 
                onChange={e => setDetails({...details,IFSC:e.target.value})} 
                value={details.IFSC} 
            /><br /> 
 
            date 
            <input  
                type="date" 
                name="date" 
                id="date"  
                placeholder="Enter date of coduct" 
                onChange={e => setDetails({...details,date:e.target.value})} 
                value={details.date} 
            /><br /> 
 
            fromTime 
            <input  
                type="time" 
                name="fromTime" 
                id="fromTime"  
                placeholder="Enter from time" 
                onChange={e => setDetails({...details,fromTime:e.target.value})} 
                value={details.fromTime} 
            /><br /> 
 
            toTime 
            <input  
                type="time" 
                name="toTime" 
                id="toTime"  
                placeholder="Enter to time" 
                onChange={e => setDetails({...details,toTime:e.target.value})} 
                value={details.toTime} 
            /><br /> 
 
            instructor 
 
            <input  
                type="text" 
                name="instructor" 
                id="instructor"  
                placeholder="Enter instructor name" 
                onChange={e => setDetails({...details,instructor:e.target.value})} 
                value={details.instructor} 
            /> 


            <button
            type="submit">
                Create    
            </button>
 
            
        </form> 
    ) 
 
} 
 
export default Create;