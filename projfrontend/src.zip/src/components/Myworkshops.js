import { useState , useEffect , useContext} from 'react';
import axios from 'axios';
import Card from './Card';
import { Link } from 'react-router-dom';
import NavBar from './contexts/Navbar';
import "./css/wrapper.css";

const Myworkshops = () => {

    const [workshops , setWorkshops] = useState([])
    const [role , setRole ] = useState(0)
    const [searchTerm , setSearchTerm] = useState("")
    

    useEffect(async () => {
        await axios.get(
            `http://localhost:8000/api/workshops/${localStorage.getItem("id")}`,
            { headers: {"Authorization" : `Bearer ${ localStorage.getItem("token")}`} }
          ).then(
              res => setWorkshops(res.data)
          )
        },[])
    
    useEffect( () => {
            setRole(localStorage.getItem("role"))
    } , [])

    

    return (
        <div className="workshops">
            <NavBar/>
            <h1>My workshops</h1>
            <input 
                type="text" 
                placeholder="Search .. "
                onChange = {
                    (event) => {
                        setSearchTerm(event.target.value)
                    }
                }
            />
            <div className="wrapper">

            {
                workshops.filter( 
                    (ws) => {
                        if(searchTerm == "")
                            return ws.name;
                        else if(ws.name.toLowerCase().includes(searchTerm.toLowerCase()))
                        return ws;
                    }
                 ).map( (ws,key) => {
                     return (
                        <Card className="user" workshop={ws}/>
                     )
                 } )
            }

            </div>
            

           

        </div>
    )
}
export default Myworkshops;